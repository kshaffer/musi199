#!/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS/Python
import music21
from music21.figuredBass import realizer
from music21.figuredBass import rules
from music21 import note
from music21 import pitch
from music21 import tempo
from music21 import key
from music21 import meter
from music21.note import Note
from music21 import converter
from music21 import duration
from music21 import interval
from music21 import lily
from music21 import scale
from music21 import stream
from music21.stream import Stream
from music21 import voiceLeading
import random

defaultFigureRepMajor = { \
'T1':[''], \
'D2':['6', '6,4', '4,3'], \
'S2':['', '7'], \
'T3':['6'], \
'S4':['', '6', '6,5'], \
'D4':['4,2'], \
'D5':['', '7'], \
'D5c':['6,4', '5,4'], \
'Tx6':[''], \
'S6':['6'], \
'D7':['6', '6,5'] }

defaultFigureRepMinor = { \
'T1':[''], \
'D2':['6+', '6+,4', '6+,4,3'], \
'S2':['', '7'], \
'T3':['6'], \
'S4':['', '6', '6,5'], \
'D4':['4+,2'], \
'D5':['+', '7,+'], \
'D5c':['6,4', '5,4'], \
'Tx6':[''], \
'S6':['6'], \
'D7':['6', '6,5'] }

def randomMajorKey():
    return str(random.sample([ 'C-', 'C', 'C#', 'D-', 'D', 'E-', 'E', 'F', 'F#', 'G-', 'G', 'A-', 'A', 'B-', 'B' ],1)[0])

def randomMinorKey():
    return str(random.sample([ 'c', 'c#', 'd', 'd#', 'e-', 'e', 'f', 'f#', 'g', 'g#', 'a-', 'a', 'a#', 'b-', 'b' ],1)[0])
    
class WellFormedBass(object):
    def __init__(self, BassStream = None):
        self.BassStream = BassStream
        self.legalMelodicIntervals = ['P4', 'P5', 'P8', 'P1', 'A1', 'm2', 'M2', 'm3', 'M3', 'm6']

    def isValidStep(self, note11, note12):
        '''Determines if the melodic interval between two given notes is "legal"
        according to 21M.301 rules of counterpoint. Legal melodic intervals
        include 'P4', 'P5', 'P8', 'm2', 'M2', 'm3', 'M3', and 'm6'.

        SHOULD BE RENAMED isValidMelody?


        >>> from music21 import *
        >>> c = note.Note('C4')
        >>> d = note.Note('D4')
        >>> e = note.Note('E#4')
        >>> cp = ModalCounterpoint()
        >>> cp.isValidStep(c, d)
        True
        >>> cp.isValidStep(c, c)
        False
        >>> cp.isValidStep(c, e)
        False

        '''
        interval1 = interval.notesToInterval(note11, note12)
        if interval1.diatonic.name in self.legalMelodicIntervals:
            return True
        else:
            return False

    def isValidMelody(self, stream1):
        '''Given a single stream, returns True if all melodic intervals
        between notes are legal and False otherwise. Legal melodic intervals
        include 'P4', 'P5', 'P8', 'm2', 'M2', 'm3', 'M3', and 'm6'.

        SHOULD BE RENAMED allValidMelody?


        >>> from music21 import *
        >>> n1 = note.Note('G-4')
        >>> n2 = note.Note('A4')
        >>> n3 = note.Note('B4')
        >>> n4 = note.Note('B5')
        >>> m1 = note.Note('G4')
        >>> m2 = note.Note('A4')
        >>> m3 = note.Note('B4')
        >>> m4 = note.Note('C5')
        >>> bass = stream.Stream()
        >>> bass.append([n1, n2, n3, n4])
        >>> sop = stream.Stream()
        >>> sop.append([m1, m2, m3, m4])
        >>> cp = ModalCounterpoint(stream1 = bass, stream2 = sop)
        >>> cp.isValidMelody(cp.stream1)
        False
        >>> n1.name = 'F#4'
        >>> cp.isValidMelody(cp.stream2)
        True

        '''
        numBadSteps = self.countBadSteps(stream1)
        if numBadSteps == 0:
            return True
        else:
            return False
        
    def countBadSteps(self, stream1):
        '''Given a single stream, returns the number of illegal melodic
        intervals.

        SHOULD BE RENAMED countBadMelodies?


        >>> from music21 import *
        >>> n1 = note.Note('G-4')
        >>> n2 = note.Note('A4')
        >>> n3 = note.Note('B4')
        >>> n4 = note.Note('A5')
        >>> m1 = note.Note('G4')
        >>> m2 = note.Note('A4')
        >>> m3 = note.Note('B4')
        >>> m4 = note.Note('C5')
        >>> bass = stream.Stream()
        >>> bass.append([n1, n2, n3, n4])
        >>> sop = stream.Stream()
        >>> sop.append([m1, m2, m3, m4])
        >>> cp = ModalCounterpoint(stream1 = bass, stream2 = sop)
        >>> cp.countBadSteps(cp.stream1)
        2
        >>> n1.name = 'F#4'
        >>> cp.countBadSteps(cp.stream2)
        0
    
        '''
        numBadSteps = 0
        sn = stream1.notesAndRests
        for i in range(len(sn)-1):
            note1 = sn[i]
            note2 = sn[i+1]
            if note2 is not None:
                if not self.isValidStep(note1, note2):
                    numBadSteps += 1
        return numBadSteps

class FunctionalBass(object):
    def __init__(self, funcBassLine = None, figureRep = defaultFigureRepMinor):
        self.funcBassLine = funcBassLine
        self.figureRep = figureRep
    
    timeSig = '2/4'
    bpm = 80
    tonic = 'G'
    mode = 'minor'
    
    def bassPitchClass(self,funcBassChord):
        if '+' in funcBassChord:
            if self.mode == 'major':
                sc = scale.MajorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)).transpose('a1'))
            elif self.mode == 'minor':
                sc = scale.MinorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)).transpose('a1'))
            else:
                print 'Unknown mode:', mode
        if '-' in funcBassChord:
            if self.mode == 'major':
                sc = scale.MajorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)).transpose('-a1'))
            elif self.mode == 'minor':
                sc = scale.MinorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)).transpose('-a1'))
            else:
                print 'Unknown mode:', mode            
        else:
            if self.mode == 'major':
                sc = scale.MajorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)))
            elif self.mode == 'minor':
                sc = scale.MinorScale(self.tonic)
                return str(sc.pitchFromDegree(self.bassScaleDegree(funcBassChord)))
            else:
                print 'Unknown mode:', mode
    
    def bassScaleDegree(self,funcBassChord):
        for degree in range(1,7):
            if str(degree) in funcBassChord:
                return float(degree)

    def bassFigure(self,funcBassChord):
        figurePossibilities = self.figureRep[funcBassChord]
        length = len(figurePossibilities)
        if length == 1:
            return figurePossibilities[0]
        if length > 1:
            indexNumber = random.randint(0,length - 1)
            return figurePossibilities[indexNumber]

    def bassRegister(self,lowestOctave,highestOctave):
        return random.randint(lowestOctave,highestOctave)
        
    def thoroughbass(self):
        print 'Key of:', self.tonic
        i = 0
        success = 'False'
        while success == 'False' and i < 10:
            figBassLine = realizer.FiguredBassLine(key.Key(self.tonic), meter.TimeSignature(self.timeSig))
            figBassRules = rules.Rules()
            figBassRules.partMovementLimits = [(1,2),(2,12),(3,12)]
            bassLine = stream.Stream()
            
            for chord in self.funcBassLine:
                sn = bassLine.notesAndRests
                if len(sn) > 0:
                    bassLen = len(sn)
                    note1 = sn[bassLen - 1]
                    note2 = pitch.Pitch(self.bassPitchClass(chord))
                    note2.octave = self.bassRegister(2,3)
                    tb = WellFormedBass()
                    if tb.isValidStep(note1, note2):
                        bassLine.append(note.Note(note2))
                        figBassLine.addElement(note.Note(note2), self.bassFigure(chord))
                    else:
                        if note2.octave == 2:
                            note2.octave = 3
                            bassLine.append(note.Note(note2))
                            figBassLine.addElement(note.Note(note2), self.bassFigure(chord))
                        if note2.octave == 3:
                            note2.octave = 2
                            bassLine.append(note.Note(note2))
                            figBassLine.addElement(note.Note(note2), self.bassFigure(chord))
                            
                else:
                    note2 = pitch.Pitch(self.bassPitchClass(chord))
                    note2.octave = self.bassRegister(2,3)
                    bassLine.append(note.Note(note2))
                    figBassLine.addElement(note.Note(note2), self.bassFigure(chord))
        
            tb = WellFormedBass()
            if tb.isValidMelody(bassLine):
                allSols = figBassLine.realize(figBassRules)
                realization = allSols.generateRandomRealization()
                realization.insert(0, tempo.MetronomeMark(number = self.bpm))
                print "Key of", self.tonic
                return realization
            else:
                print 'Failed attempt.'
                success = 'False'
                i += 1