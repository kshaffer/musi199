#!/Library/Frameworks/Python.framework/Versions/2.7/Resources/Python.app/Contents/MacOS/Python

# takes functional bass line and possible figures for each chord,
# generates figured bass line, realizes figured bass line

# program makes up to five attempts to realize functional bass with
# good bass voice-leading. After five failed attempts, program assumes
# not possible and gives up.

# A good bass line will conform to good species CF rules (with possible
# bass repetition allowed) with no leaps larger than 8ve and will contain 
# only notes from octaves 2 and 3.

# only designed for major keys so far

# TO DO:
# allow non-uniform rhythm

from music21 import *
from BassGenerator import *

# allowable Functional Bass chord symbols:
# T1, D2, S2, T3, S4, D4, D5, D5c, Tx6, S6, D7
# (D5c = the first chord of a compound cadence, e.g., cadential 6/4 or 
# 5/4 chord in a 4-3 (5/4-5/3 or 8/5/4-7/5/3) suspension)

funcBassLine1 = ['T1', 'S4', 'D5c', 'D5', 'T1']
funcBassLine2 = ['T1', 'T3', 'S4', 'D5c', 'D5', 'T1']
funcBassLine3 = ['T1', 'D2', 'T3inv', 'S4', 'D5', 'T1']
funcBassLine4 = ['D5', 'D4', 'T3inv', 'S4', 'D5', 'T1']
funcBassLine5 = ['T1', 'T3', 'D5c', 'D5', 'T1']
funcBassLine6 = ['D5', 'D4', 'T3inv', 'D2', 'T1']
funcBassLine7 = ['T1', 'S6', 'T3', 'S4', 'D5', 'T1']
funcBassLine8 = ['T1', 'S6', 'S4', 'D5', 'T1']
funcBassLine9 = ['T1', 'S4', 'S2', 'D5', 'T1']
funcBassLine10 = ['T1', 'D-7', 'S6', 'D5', 'T1']
funcBassLine11 = ['T1', 'Tx6', 'S4', 'D5', 'T1']
funcBassLine12 = ['T1', 'D2', 'T3inv', 'S4', 'D5', 'D4', 'T3inv']
funcBassLine13 = ['T1', 'D7', 'T1', 'T3', 'S4', 'D5', 'T1']
funcBassLine14 = ['T1', 'D5', 'Tx6', 'T3', 'S4', 'D5', 'T1']


funcBassPoss = [ funcBassLine1, funcBassLine2, funcBassLine3, funcBassLine4, funcBassLine5, funcBassLine6, funcBassLine7, funcBassLine8, funcBassLine9, funcBassLine10, funcBassLine11, funcBassLine12, funcBassLine13, funcBassLine14 ]

funcBassLine = random.sample(funcBassPoss,1)[0]

# Define repertoire of possible figures
T1figs = ['']
D2figs = ['6+', '6+,4', '6+,4,3']
S2figs = ['', '7']
T3figs = ['6', '']
T3invfigs = ['6']
S4figs = ['', '6', '6,5']
D4figs = ['4+,2']
D5figs = ['+', '7,+']
D5cfigs = ['6,4', '5,4']
Tx6figs = ['']
S6figs = ['6']
D7figs = ['6', '6,5']
Dlowered7figs = ['6']

# do not modify below this line -----------------------------------

figureRep = { \
'T1':T1figs, \
'D2':D2figs, \
'S2':S2figs, \
'T3':T3figs, \
'T3inv':T3invfigs, \
'S4':S4figs, \
'D4':D4figs, \
'D5':D5figs, \
'D5c':D5cfigs, \
'Tx6':Tx6figs, \
'S6':S6figs, \
'D7':D7figs, \
'D-7':Dlowered7figs }

fb = FunctionalBass(funcBassLine,figureRep)
fb.tonic = randomMinorKey()
fb.mode = 'minor'

result = fb.thoroughbass()
result.show('midi')
if raw_input('Press return to see solution.') == '':
	result.show('musicxml')